"""
render_stl_images.py
Renders high-resolution technical CAD images directly from the generated STL files
using pure Python (numpy + PIL) with Lambertian directional lighting and edge enhancement.
100% Synchronized with KiCad PCB Layout: co_detector_controller.kicad_pcb
"""

import math
import os
import struct
import numpy as np
from PIL import Image, ImageDraw

def read_stl_triangles(stl_path):
    with open(stl_path, "rb") as f:
        f.seek(80)
        n_tri = struct.unpack("<I", f.read(4))[0]
        record_dtype = np.dtype([
            ('normal', '<f4', (3,)),
            ('v1', '<f4', (3,)),
            ('v2', '<f4', (3,)),
            ('v3', '<f4', (3,)),
            ('attr', '<u2')
        ])
        data = np.frombuffer(f.read(n_tri * 50), dtype=record_dtype)
        tris = np.stack([data['v1'], data['v2'], data['v3']], axis=1)
        normals = data['normal']
        return tris, normals

def get_rotation_matrix(pitch_deg, yaw_deg, roll_deg=0):
    p = math.radians(pitch_deg)
    y = math.radians(yaw_deg)
    r = math.radians(roll_deg)
    
    Rx = np.array([
        [1, 0, 0],
        [0, math.cos(p), -math.sin(p)],
        [0, math.sin(p), math.cos(p)]
    ])
    Ry = np.array([
        [math.cos(y), 0, math.sin(y)],
        [0, 1, 0],
        [-math.sin(y), 0, math.cos(y)]
    ])
    Rz = np.array([
        [math.cos(r), -math.sin(r), 0],
        [math.sin(r), math.cos(r), 0],
        [0, 0, 1]
    ])
    return Rz @ Rx @ Ry

def render_mesh_scene(parts_config, out_img_path, width=1600, height=1200, 
                      pitch=30, yaw=-45, title="CAD Visualisation"):
    img = Image.new("RGBA", (width, height), (15, 20, 28, 255))
    draw = ImageDraw.Draw(img)
    
    # Background gradient
    for y in range(height):
        factor = y / height
        r = int(15 * (1 - factor) + 24 * factor)
        g = int(20 * (1 - factor) + 32 * factor)
        b = int(28 * (1 - factor) + 45 * factor)
        draw.line([(0, y), (width, y)], fill=(r, g, b, 255))

    R = get_rotation_matrix(pitch, yaw)
    light_dir = np.array([0.4, 0.6, 0.7])
    light_dir = light_dir / np.linalg.norm(light_dir)
    
    all_polys = []
    all_pts_for_bounds = []
    
    for p in parts_config:
        tris, normals = read_stl_triangles(p['stl'])
        offset = np.array(p.get('offset', [0, 0, 0]), dtype=np.float32)
        tris = tris + offset
        tris_centered = tris - np.array([41.0, 31.0, 10.0])
        
        rot_tris = np.einsum('ij,nkj->nki', R, tris_centered)
        
        v1 = rot_tris[:, 0, :]
        v2 = rot_tris[:, 1, :]
        v3 = rot_tris[:, 2, :]
        norms = np.cross(v2 - v1, v3 - v1)
        norm_len = np.linalg.norm(norms, axis=1, keepdims=True)
        norm_len[norm_len == 0] = 1.0
        norms = norms / norm_len
        
        mean_z = np.mean(rot_tris[:, :, 2], axis=1)
        base_color = np.array(p['color'], dtype=np.float32)
        
        for i in range(len(rot_tris)):
            if norms[i, 2] <= -0.05:
                continue
                
            dot = np.dot(norms[i], light_dir)
            intensity = 0.35 + 0.65 * max(0.0, dot)
            
            c = np.clip(base_color * intensity, 0, 255).astype(int)
            fill_color = (int(c[0]), int(c[1]), int(c[2]), 255)
            
            edge_c = np.clip(base_color * intensity * 0.75, 0, 255).astype(int)
            outline_color = (int(edge_c[0]), int(edge_c[1]), int(edge_c[2]), 180)
            
            all_polys.append({
                'z': mean_z[i],
                'pts_3d': rot_tris[i],
                'fill': fill_color,
                'outline': outline_color
            })
            all_pts_for_bounds.append(rot_tris[i])

    all_pts_stacked = np.concatenate(all_pts_for_bounds, axis=0)
    min_x, max_x = np.min(all_pts_stacked[:, 0]), np.max(all_pts_stacked[:, 0])
    min_y, max_y = np.min(all_pts_stacked[:, 1]), np.max(all_pts_stacked[:, 1])
    
    range_x = max(1.0, max_x - min_x)
    range_y = max(1.0, max_y - min_y)
    
    scale = min((width * 0.75) / range_x, (height * 0.75) / range_y)
    center_proj_x = (min_x + max_x) / 2.0
    center_proj_y = (min_y + max_y) / 2.0
    
    all_polys.sort(key=lambda item: item['z'])
    
    for poly in all_polys:
        pts_2d = []
        for pt in poly['pts_3d']:
            px = int((pt[0] - center_proj_x) * scale + width / 2.0)
            py = int(height / 2.0 - (pt[1] - center_proj_y) * scale)
            pts_2d.append((px, py))
        draw.polygon(pts_2d, fill=poly['fill'], outline=poly['outline'])
        
    draw.rectangle([(24, 24), (500, 110)], fill=(15, 20, 28, 220), outline=(255, 255, 255, 30))
    draw.text((40, 36), "SMART DUAL GAS DETECTOR", fill=(96, 165, 250))
    draw.text((40, 58), title, fill=(255, 255, 255))
    draw.text((40, 82), "KiCad PCB Rev 2.0 Synchronized (70x50mm)", fill=(148, 163, 184))
    
    img.save(out_img_path, "PNG")
    print(f"Rendered {out_img_path} ({os.path.getsize(out_img_path)/1024:.1f} KB)")


if __name__ == "__main__":
    stl_dir = r"C:\Users\naoufal\.gemini\antigravity\scratch\co-detector-controller\enclosure\stl"
    out_dir = r"C:\Users\naoufal\.gemini\antigravity\scratch\co-detector-controller\enclosure\docs\images"
    os.makedirs(out_dir, exist_ok=True)
    
    base_stl = os.path.join(stl_dir, "co_detector_enclosure_base_shell.stl")
    top_stl = os.path.join(stl_dir, "co_detector_enclosure_top_cover.stl")
    bracket_stl = os.path.join(stl_dir, "co_detector_enclosure_wall_bracket.stl")
    btn_stl = os.path.join(stl_dir, "co_detector_enclosure_button_actuator.stl")
    lp_stl = os.path.join(stl_dir, "co_detector_enclosure_light_pipe.stl")
    
    print("=== Rendering Synchronized 3D CAD Views ===")
    
    # Coordinates: Button is at (48, 47) in outer box (offset x=7, y=16 from center)
    # Lightpipe is at (38, 52) in outer box (offset x=-3, y=21 from center)
    btn_offset_assembled = (48.0, 47.0, 25.0)
    lp_offset_assembled  = (37.6, 52.0, 22.0)
    
    # 1. Isometric Assembled View
    scene_assembled = [
        {'stl': base_stl, 'color': (51, 65, 85), 'offset': (0, 0, 0)},
        {'stl': top_stl, 'color': (226, 232, 240), 'offset': (0, 0, 8.5)},
        {'stl': btn_stl, 'color': (37, 99, 235), 'offset': btn_offset_assembled},
        {'stl': lp_stl, 'color': (186, 230, 253), 'offset': lp_offset_assembled},
    ]
    render_mesh_scene(scene_assembled, os.path.join(out_dir, "enclosure_isometric_assembled.png"), 
                      pitch=28, yaw=-40, title="Assembled Enclosure - Isometric View")
                      
    # 2. Front Face-on View
    render_mesh_scene(scene_assembled, os.path.join(out_dir, "enclosure_front_view.png"), 
                      pitch=0, yaw=0, title="Front Interface & Annunciation Panel")
                      
    # 3. Side & Port Access View (Left Edge with Cable Ports J1 & J2)
    render_mesh_scene(scene_assembled, os.path.join(out_dir, "enclosure_side_ports_view.png"), 
                      pitch=15, yaw=90, title="Side Profile & Solenoid Wiring Ports")
                      
    # 4. Exploded CAD View
    scene_exploded = [
        {'stl': bracket_stl, 'color': (30, 41, 59), 'offset': (0, 0, -22.0)},
        {'stl': base_stl, 'color': (51, 65, 85), 'offset': (0, 0, 0)},
        {'stl': top_stl, 'color': (226, 232, 240), 'offset': (0, 0, 36.0)},
        {'stl': btn_stl, 'color': (37, 99, 235), 'offset': (48.0, 47.0, 62.0)},
        {'stl': lp_stl, 'color': (186, 230, 253), 'offset': (37.6, 52.0, 56.0)},
    ]
    render_mesh_scene(scene_exploded, os.path.join(out_dir, "enclosure_exploded_cad_view.png"), 
                      pitch=32, yaw=-45, title="Exploded Mechanical Assembly View")
                      
    print("=== All 3D CAD Views Rendered Successfully! ===")
