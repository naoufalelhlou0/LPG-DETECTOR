"""
build_enclosure_stl.py
Generates high-precision binary STL files for the Smart Dual Gas Detector (CO + LPG) Controller Enclosure.
100% Synchronized with KiCad PCB Layout: co_detector_controller.kicad_pcb
"""

import math
import os
import struct
import numpy as np

def write_binary_stl(filename, triangles):
    num_triangles = len(triangles)
    header = f"Smart CO+LPG Enclosure - Rev 2.0 - {os.path.basename(filename)}".encode("ascii").ljust(80, b"\0")[:80]
    
    with open(filename, "wb") as f:
        f.write(header)
        f.write(struct.pack("<I", num_triangles))
        
        v1 = triangles[:, 0, :]
        v2 = triangles[:, 1, :]
        v3 = triangles[:, 2, :]
        normals = np.cross(v2 - v1, v3 - v1)
        norm_len = np.linalg.norm(normals, axis=1, keepdims=True)
        norm_len[norm_len == 0] = 1.0
        normals = normals / norm_len
        
        record_dtype = np.dtype([
            ('normal', '<f4', (3,)),
            ('v1', '<f4', (3,)),
            ('v2', '<f4', (3,)),
            ('v3', '<f4', (3,)),
            ('attr', '<u2')
        ])
        
        records = np.empty(num_triangles, dtype=record_dtype)
        records['normal'] = normals
        records['v1'] = v1
        records['v2'] = v2
        records['v3'] = v3
        records['attr'] = 0
        
        f.write(records.tobytes())
    
    print(f"Generated {filename}: {num_triangles} triangles ({os.path.getsize(filename)/1024:.1f} KB)")


class MeshBuilder:
    def __init__(self):
        self.triangles = []

    def add_quad(self, p1, p2, p3, p4):
        self.triangles.append([p1, p2, p3])
        self.triangles.append([p1, p3, p4])

    def add_triangle(self, p1, p2, p3):
        self.triangles.append([p1, p2, p3])

    def add_box(self, x0, y0, z0, x1, y1, z1):
        c = [
            [x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0],
            [x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]
        ]
        self.add_quad(c[0], c[3], c[2], c[1]) # Bottom
        self.add_quad(c[4], c[5], c[6], c[7]) # Top
        self.add_quad(c[0], c[1], c[5], c[4]) # Front
        self.add_quad(c[1], c[2], c[6], c[5]) # Right
        self.add_quad(c[2], c[3], c[7], c[6]) # Back
        self.add_quad(c[3], c[0], c[4], c[7]) # Left

    def add_cylinder(self, r, z0, z1, cx=0.0, cy=0.0, n=32, caps=True):
        angles = np.linspace(0, 2 * math.pi, n, endpoint=False)
        bot_pts = [[cx + r * math.cos(a), cy + r * math.sin(a), z0] for a in angles]
        top_pts = [[cx + r * math.cos(a), cy + r * math.sin(a), z1] for a in angles]
        
        for i in range(n):
            nxt = (i + 1) % n
            self.add_quad(bot_pts[i], bot_pts[nxt], top_pts[nxt], top_pts[i])
            
        if caps:
            bot_center = [cx, cy, z0]
            top_center = [cx, cy, z1]
            for i in range(n):
                nxt = (i + 1) % n
                self.add_triangle(bot_center, bot_pts[nxt], bot_pts[i])
                self.add_triangle(top_center, top_pts[i], top_pts[nxt])

    def add_tube(self, r_out, r_in, z0, z1, cx=0.0, cy=0.0, n=32):
        angles = np.linspace(0, 2 * math.pi, n, endpoint=False)
        out_bot = [[cx + r_out * math.cos(a), cy + r_out * math.sin(a), z0] for a in angles]
        out_top = [[cx + r_out * math.cos(a), cy + r_out * math.sin(a), z1] for a in angles]
        in_bot  = [[cx + r_in  * math.cos(a), cy + r_in  * math.sin(a), z0] for a in angles]
        in_top  = [[cx + r_in  * math.cos(a), cy + r_in  * math.sin(a), z1] for a in angles]
        
        for i in range(n):
            nxt = (i + 1) % n
            self.add_quad(out_bot[i], out_bot[nxt], out_top[nxt], out_top[i])
            self.add_quad(in_bot[nxt], in_bot[i], in_top[i], in_top[nxt])
            self.add_quad(out_bot[nxt], out_bot[i], in_bot[i], in_bot[nxt])
            self.add_quad(out_top[i], out_top[nxt], in_top[nxt], in_top[i])

    def add_rounded_profile(self, width, length, r, n_per_corner=8):
        pts = []
        corners = [
            (width - r, length - r, 0),
            (r, length - r, math.pi / 2),
            (r, r, math.pi),
            (width - r, r, 3 * math.pi / 2)
        ]
        for cx, cy, start_ang in corners:
            for i in range(n_per_corner):
                ang = start_ang + (math.pi / 2) * (i / n_per_corner)
                pts.append([cx + r * math.cos(ang), cy + r * math.sin(ang)])
        return pts

    def add_rounded_box(self, width, length, height, r, z0=0.0, n_per_corner=8, top_cap=True, bot_cap=True):
        poly2d = self.add_rounded_profile(width, length, r, n_per_corner)
        m = len(poly2d)
        bot = [[p[0], p[1], z0] for p in poly2d]
        top = [[p[0], p[1], z0 + height] for p in poly2d]
        
        for i in range(m):
            nxt = (i + 1) % m
            self.add_quad(bot[i], bot[nxt], top[nxt], top[i])
            
        cx, cy = width / 2.0, length / 2.0
        if bot_cap:
            b_cent = [cx, cy, z0]
            for i in range(m):
                nxt = (i + 1) % m
                self.add_triangle(b_cent, bot[nxt], bot[i])
        if top_cap:
            t_cent = [cx, cy, z0 + height]
            for i in range(m):
                nxt = (i + 1) % m
                self.add_triangle(t_cent, top[i], top[nxt])

    def add_rounded_hollow_shell(self, outer_w, outer_l, outer_h, wall_t, r, z0=0.0, floor_t=2.5, n_per_corner=8):
        in_w = outer_w - 2 * wall_t
        in_l = outer_l - 2 * wall_t
        in_r = max(1.0, r - wall_t)
        
        out_poly = self.add_rounded_profile(outer_w, outer_l, r, n_per_corner)
        in_poly  = self.add_rounded_profile(in_w, in_l, in_r, n_per_corner)
        in_poly  = [[p[0] + wall_t, p[1] + wall_t] for p in in_poly]
        m = len(out_poly)
        
        out_bot = [[p[0], p[1], z0] for p in out_poly]
        out_top = [[p[0], p[1], z0 + outer_h] for p in out_poly]
        for i in range(m):
            nxt = (i + 1) % m
            self.add_quad(out_bot[i], out_bot[nxt], out_top[nxt], out_top[i])
            
        in_bot = [[p[0], p[1], z0 + floor_t] for p in in_poly]
        in_top = [[p[0], p[1], z0 + outer_h] for p in in_poly]
        for i in range(m):
            nxt = (i + 1) % m
            self.add_quad(in_bot[nxt], in_bot[i], in_top[i], in_top[nxt])
            
        cx, cy = outer_w / 2.0, outer_l / 2.0
        b_cent = [cx, cy, z0]
        for i in range(m):
            nxt = (i + 1) % m
            self.add_triangle(b_cent, out_bot[nxt], out_bot[i])
            
        for i in range(m):
            nxt = (i + 1) % m
            self.add_quad(out_top[i], out_top[nxt], in_top[nxt], in_top[i])
            
        f_cent = [cx, cy, z0 + floor_t]
        for i in range(m):
            nxt = (i + 1) % m
            self.add_triangle(f_cent, in_bot[i], in_bot[nxt])

    def get_numpy_triangles(self):
        return np.array(self.triangles, dtype=np.float32)


# ==============================================================================
# ENCLOSURE PART BUILDERS (SYNCHRONIZED WITH KICAD PCB)
# ==============================================================================

def build_base_shell(stl_path):
    b = MeshBuilder()
    outer_w, outer_l, outer_h = 82.0, 62.0, 8.5
    wall_t, floor_t, corner_r = 2.5, 2.5, 5.0
    
    # 1. Main Hollow Shell
    b.add_rounded_hollow_shell(outer_w, outer_l, outer_h, wall_t, corner_r, z0=0.0, floor_t=floor_t)
    
    # 2. Interlocking Perimeter Tongue Lip
    lip_w = outer_w - wall_t
    lip_l = outer_l - wall_t
    lip_h = 1.8
    lip_outer = b.add_rounded_profile(lip_w, lip_l, corner_r - 0.5)
    lip_outer = [[p[0] + wall_t/2, p[1] + wall_t/2] for p in lip_outer]
    lip_inner = b.add_rounded_profile(lip_w - 2.4, lip_l - 2.4, corner_r - 1.2)
    lip_inner = [[p[0] + wall_t/2 + 1.2, p[1] + wall_t/2 + 1.2] for p in lip_inner]
    m = len(lip_outer)
    for i in range(m):
        nxt = (i + 1) % m
        o_b = [lip_outer[i][0], lip_outer[i][1], outer_h]
        o_b_nxt = [lip_outer[nxt][0], lip_outer[nxt][1], outer_h]
        o_t = [lip_outer[i][0], lip_outer[i][1], outer_h + lip_h]
        o_t_nxt = [lip_outer[nxt][0], lip_outer[nxt][1], outer_h + lip_h]
        
        i_b = [lip_inner[i][0], lip_inner[i][1], outer_h]
        i_b_nxt = [lip_inner[nxt][0], lip_inner[nxt][1], outer_h]
        i_t = [lip_inner[i][0], lip_inner[i][1], outer_h + lip_h]
        i_t_nxt = [lip_inner[nxt][0], lip_inner[nxt][1], outer_h + lip_h]
        
        b.add_quad(o_b, o_b_nxt, o_t_nxt, o_t)
        b.add_quad(i_b_nxt, i_b, i_t, i_t_nxt)
        b.add_quad(o_t, o_t_nxt, i_t_nxt, i_t)
        
    # 3. 4 PCB Mounting Standoffs (Exact KiCad positions)
    # H3=(3.5, 3.5), H4=(66.5, 3.5), H1=(3.5, 46.5), H2=(66.5, 46.5)
    off_x = (outer_w - 70.0) / 2.0  # 6.0 mm
    off_y = (outer_l - 50.0) / 2.0  # 6.0 mm
    standoff_h = 4.0
    standoff_od = 6.2
    standoff_id = 2.8
    
    pcb_holes = [(3.50, 3.50), (66.50, 3.50), (3.50, 46.50), (66.50, 46.50)]
    for hx, hy in pcb_holes:
        cx = off_x + hx
        cy = off_y + hy
        b.add_tube(standoff_od/2, standoff_id/2, floor_t, floor_t + standoff_h, cx=cx, cy=cy, n=24)
        b.add_box(cx - 0.6, cy - standoff_od/2 - 2.0, floor_t, cx + 0.6, cy + standoff_od/2 + 2.0, floor_t + 2.5)
        b.add_box(cx - standoff_od/2 - 2.0, cy - 0.6, floor_t, cx + standoff_od/2 + 2.0, cy + 0.6, floor_t + 2.5)
        
    # 4. 4 Corner Assembly Fastening Bosses
    corner_bosses = [
        (off_x - 1.5, off_y - 1.5),
        (off_x + 70.0 + 1.5, off_y - 1.5),
        (off_x - 1.5, off_y + 50.0 + 1.5),
        (off_x + 70.0 + 1.5, off_y + 50.0 + 1.5)
    ]
    for cx, cy in corner_bosses:
        b.add_tube(r_out=3.6, r_in=1.7, z0=floor_t, z1=outer_h, cx=cx, cy=cy, n=20)
        
    # 5. Left Side Cable Cutout Bosses / Relief
    # J1 12V IN: Y = off_y + 12.0 = 18.0 mm
    # J2 EXT ALARM Valve: Y = off_y + 38.0 = 44.0 mm
    b.add_box(0.0, off_y + 12.0 - 5.5, floor_t + standoff_h, wall_t, off_y + 12.0 + 5.5, outer_h)
    b.add_box(0.0, off_y + 38.0 - 5.5, floor_t + standoff_h, wall_t, off_y + 38.0 + 5.5, outer_h)
        
    # 6. Dual Wall-Mount Keyhole Bosses
    for kx in [outer_w/2 - 20.0, outer_w/2 + 20.0]:
        ky = outer_l / 2.0
        b.add_tube(r_out=5.5, r_in=4.2, z0=floor_t, z1=floor_t + 1.5, cx=kx, cy=ky, n=20)
        
    write_binary_stl(stl_path, b.get_numpy_triangles())


def build_top_cover(stl_path):
    b = MeshBuilder()
    outer_w, outer_l, outer_h = 82.0, 62.0, 19.0
    wall_t, ceiling_t, corner_r = 2.5, 2.5, 5.0
    
    in_w = outer_w - 2 * wall_t
    in_l = outer_l - 2 * wall_t
    in_r = max(1.0, corner_r - wall_t)
    
    out_poly = b.add_rounded_profile(outer_w, outer_l, corner_r, 8)
    in_poly  = b.add_rounded_profile(in_w, in_l, in_r, 8)
    in_poly  = [[p[0] + wall_t, p[1] + wall_t] for p in in_poly]
    m = len(out_poly)
    
    out_bot = [[p[0], p[1], 0.0] for p in out_poly]
    out_top = [[p[0], p[1], outer_h] for p in out_poly]
    for i in range(m):
        nxt = (i + 1) % m
        b.add_quad(out_bot[i], out_bot[nxt], out_top[nxt], out_top[i])
        
    in_bot = [[p[0], p[1], 0.0] for p in in_poly]
    in_ceil = [[p[0], p[1], outer_h - ceiling_t] for p in in_poly]
    for i in range(m):
        nxt = (i + 1) % m
        b.add_quad(in_bot[nxt], in_bot[i], in_ceil[i], in_ceil[nxt])
        
    for i in range(m):
        nxt = (i + 1) % m
        b.add_quad(out_bot[nxt], out_bot[i], in_bot[i], in_bot[nxt])
        
    cx, cy = outer_w / 2.0, outer_l / 2.0
    t_cent = [cx, cy, outer_h]
    for i in range(m):
        nxt = (i + 1) % m
        b.add_triangle(t_cent, out_top[i], out_top[nxt])
        
    c_cent = [cx, cy, outer_h - ceiling_t]
    for i in range(m):
        nxt = (i + 1) % m
        b.add_triangle(c_cent, in_ceil[nxt], in_ceil[i])
        
    off_x = (outer_w - 70.0) / 2.0  # 6.0 mm
    off_y = (outer_l - 50.0) / 2.0  # 6.0 mm
    
    # 1. OLED Window Bezel (Top-Center: X = 35.50, Y = 13.00 mm on PCB)
    oled_cx = off_x + 35.50
    oled_cy = off_y + 13.00
    oled_w, oled_h = 24.5, 13.5
    b.add_tube(r_out=14.5, r_in=13.0, z0=outer_h, z1=outer_h + 0.8, cx=oled_cx, cy=oled_cy, n=24)
    b.add_box(oled_cx - oled_w/2, oled_cy - oled_h/2, outer_h - 1.2,
              oled_cx + oled_w/2, oled_cy + oled_h/2, outer_h + 0.05)
              
    # 2. Figaro TGS2610 LPG MOS Sensor Chimney (Top-Right: X = 59.00, Y = 6.50 mm on PCB)
    lpg_cx = off_x + 59.00
    lpg_cy = off_y + 6.50
    b.add_tube(r_out=6.5, r_in=5.2, z0=outer_h, z1=outer_h + 1.4, cx=lpg_cx, cy=lpg_cy, n=24)
    for dy in [-2.5, 0.0, 2.5]:
        b.add_box(lpg_cx - 4.5, lpg_cy + dy - 0.5, outer_h, lpg_cx + 4.5, lpg_cy + dy + 0.5, outer_h + 1.4)
        
    # 3. HW Master Reset Pinhole (SW3: X = 5.45, Y = 29.80 mm on PCB)
    reset_cx = off_x + 5.45
    reset_cy = off_y + 29.80
    b.add_tube(r_out=2.2, r_in=1.1, z0=outer_h - ceiling_t, z1=outer_h + 0.5, cx=reset_cx, cy=reset_cy, n=16)
    
    # 4. Piezo Buzzer Acoustic Horn (LS1: X = 32.00, Y = 38.00 mm on PCB)
    buz_cx = off_x + 32.00
    buz_cy = off_y + 38.00
    b.add_tube(r_out=6.8, r_in=5.8, z0=outer_h, z1=outer_h + 0.9, cx=buz_cx, cy=buz_cy, n=24)
    for a in np.linspace(0, 2*math.pi, 4, endpoint=False):
        bx = buz_cx + 3.0 * math.cos(a)
        by = buz_cy + 3.0 * math.sin(a)
        b.add_box(bx - 0.6, by - 0.6, outer_h, bx + 0.6, by + 0.6, outer_h + 0.9)
    b.add_tube(r_out=6.5, r_in=5.0, z0=outer_h - ceiling_t - 5.5, z1=outer_h - ceiling_t, cx=buz_cx, cy=buz_cy, n=24)
    
    # 5. Dual Button Bezel (Bottom-Center: SW2 HUSH Y=38.0 & SW1 TEST Y=44.0 at X=42.0 mm on PCB)
    btn_cx = off_x + 42.00
    btn_cy = off_y + 41.00 # Midpoint between 38 and 44
    b.add_tube(r_out=5.0, r_in=4.2, z0=outer_h, z1=outer_h + 0.8, cx=btn_cx, cy=btn_cy - 3.0, n=20)
    b.add_tube(r_out=5.0, r_in=4.2, z0=outer_h, z1=outer_h + 0.8, cx=btn_cx, cy=btn_cy + 3.0, n=20)
    b.add_box(btn_cx - 5.0, btn_cy - 3.0, outer_h, btn_cx - 4.2, btn_cy + 3.0, outer_h + 0.8)
    b.add_box(btn_cx + 4.2, btn_cy - 3.0, outer_h, btn_cx + 5.0, btn_cy + 3.0, outer_h + 0.8)
    
    # 6. Winsen ME3-CO Gas Diffusion Intake Grille (Bottom-Right: X = 56.50, Y = 35.50 mm on PCB)
    co_cx = off_x + 56.50
    co_cy = off_y + 35.50
    b.add_tube(r_out=11.2, r_in=9.8, z0=outer_h, z1=outer_h + 1.2, cx=co_cx, cy=co_cy, n=32)
    for a in np.linspace(0, 2*math.pi, 6, endpoint=False):
        rx = co_cx + 5.5 * math.cos(a)
        ry = co_cy + 5.5 * math.sin(a)
        b.add_box(rx - 0.7, ry - 0.7, outer_h, rx + 0.7, ry + 0.7, outer_h + 1.2)
    b.add_tube(r_out=10.5, r_in=9.8, z0=outer_h - ceiling_t - 4.0, z1=outer_h - ceiling_t, cx=co_cx, cy=co_cy, n=32)
    
    # 7. Quad Status LED Light Guide Barrel (Bottom Edge: Y = 46.00 mm on PCB)
    led_xs = [26.80, 30.00, 33.20, 36.40]
    for lx in led_xs:
        cx = off_x + lx
        cy = off_y + 46.00
        b.add_cylinder(r=1.4, z0=outer_h, z1=outer_h + 0.5, cx=cx, cy=cy, n=16)
        b.add_tube(r_out=1.8, r_in=1.1, z0=outer_h - ceiling_t - 6.0, z1=outer_h - ceiling_t, cx=cx, cy=cy, n=16)
        
    # 8. 4 Corner Fastening Bosses
    corner_bosses = [
        (off_x - 1.5, off_y - 1.5),
        (off_x + 70.0 + 1.5, off_y - 1.5),
        (off_x - 1.5, off_y + 50.0 + 1.5),
        (off_x + 70.0 + 1.5, off_y + 50.0 + 1.5)
    ]
    for cx, cy in corner_bosses:
        b.add_tube(r_out=3.6, r_in=1.5, z0=outer_h - ceiling_t - 14.0, z1=outer_h - ceiling_t, cx=cx, cy=cy, n=20)
        
    write_binary_stl(stl_path, b.get_numpy_triangles())


def build_wall_bracket(stl_path):
    b = MeshBuilder()
    bw, bl, bh = 76.0, 56.0, 3.5
    corner_r = 4.0
    
    b.add_rounded_box(bw, bl, bh, corner_r, z0=0.0)
    for kx in [bw/2 - 20.0, bw/2 + 20.0]:
        ky = bl / 2.0
        b.add_cylinder(r=1.9, z0=bh, z1=bh + 3.0, cx=kx, cy=ky, n=20)
        b.add_cylinder(r=3.8, z0=bh + 2.2, z1=bh + 3.4, cx=kx, cy=ky, n=20)
        
    b.add_box(bw/2 - 8.0, 1.0, 0.0, bw/2 + 8.0, 7.0, bh + 1.5)
    write_binary_stl(stl_path, b.get_numpy_triangles())


def build_button_actuator(stl_path):
    b = MeshBuilder()
    # Spans between SW2 (Y=38) and SW1 (Y=44): delta Y = 6.0 mm
    b.add_cylinder(r=3.4, z0=0.0, z1=2.8, cx=0.0, cy=-3.0, n=24)
    b.add_cylinder(r=3.4, z0=0.0, z1=2.8, cx=0.0, cy=3.0, n=24)
    b.add_box(-3.4, -3.0, 0.0, 3.4, 3.0, 2.8)
    b.add_box(-4.5, -4.2, 0.0, 4.5, 4.2, 0.9)
    b.add_cylinder(r=1.2, z0=-9.0, z1=0.0, cx=0.0, cy=-3.0, n=16)
    b.add_cylinder(r=1.2, z0=-9.0, z1=0.0, cx=0.0, cy=3.0, n=16)
    b.add_cylinder(r=1.5, z0=2.8, z1=3.4, cx=0.0, cy=-3.0, n=16)
    b.add_cylinder(r=1.5, z0=2.8, z1=3.4, cx=0.0, cy=3.0, n=16)
    write_binary_stl(stl_path, b.get_numpy_triangles())


def build_light_pipes(stl_path):
    b = MeshBuilder()
    # Pitch is exactly 3.20 mm matching D4, D5, D6, D8
    xs = [-4.8, -1.6, 1.6, 4.8]
    for x in xs:
        b.add_cylinder(r=1.0, z0=0.0, z1=7.0, cx=x, cy=0.0, n=20)
        b.add_cylinder(r=1.1, z0=6.8, z1=7.4, cx=x, cy=0.0, n=20)
    b.add_box(-6.0, -0.7, 2.0, 6.0, 0.7, 3.2)
    write_binary_stl(stl_path, b.get_numpy_triangles())


def build_complete_assembly(stl_path, base_stl, top_stl):
    def read_stl(path):
        with open(path, "rb") as f:
            f.seek(80)
            n_tri = struct.unpack("<I", f.read(4))[0]
            record_dtype = np.dtype([
                ('normal', '<f4', (3,)),
                ('v1', '<f4', (3,)),
                ('v2', '<f4', (3,)),
                ('v3', '<f4', (3,)),
                ('attr', '<u2')
            ])
            data = np.frombuffer(f.read(n_tri * 50), dtype=record_dtype)
            tris = np.stack([data['v1'], data['v2'], data['v3']], axis=1)
            return tris
            
    base_tris = read_stl(base_stl)
    top_tris = read_stl(top_stl)
    
    top_tris_shifted = top_tris.copy()
    top_tris_shifted[:, :, 2] += 8.5
    
    all_tris = np.concatenate([base_tris, top_tris_shifted], axis=0)
    write_binary_stl(stl_path, all_tris)


if __name__ == "__main__":
    out_dir = r"C:\Users\naoufal\.gemini\antigravity\scratch\co-detector-controller\enclosure\stl"
    os.makedirs(out_dir, exist_ok=True)
    
    base_file = os.path.join(out_dir, "co_detector_enclosure_base_shell.stl")
    top_file = os.path.join(out_dir, "co_detector_enclosure_top_cover.stl")
    bracket_file = os.path.join(out_dir, "co_detector_enclosure_wall_bracket.stl")
    btn_file = os.path.join(out_dir, "co_detector_enclosure_button_actuator.stl")
    lp_file = os.path.join(out_dir, "co_detector_enclosure_light_pipe.stl")
    assembly_file = os.path.join(out_dir, "co_detector_enclosure_assembly.stl")
    
    print("=== Generating Corrected 3D Enclosure STL Models ===")
    build_base_shell(base_file)
    build_top_cover(top_file)
    build_wall_bracket(bracket_file)
    build_button_actuator(btn_file)
    build_light_pipes(lp_file)
    build_complete_assembly(assembly_file, base_file, top_file)
    print("=== All STL Models Synchronized & Generated Successfully! ===")
