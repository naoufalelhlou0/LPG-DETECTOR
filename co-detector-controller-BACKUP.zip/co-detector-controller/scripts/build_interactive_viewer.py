"""
build_interactive_viewer.py
Reads generated STL files, compresses/serializes geometry, and embeds into a
self-contained, ultra-responsive HTML5 / WebGL Three.js interactive 3D viewer.
100% Synchronized with KiCad PCB Layout: co_detector_controller.kicad_pcb
"""

import base64
import json
import os
import struct
import numpy as np

def read_stl_vertices(stl_path):
    with open(stl_path, "rb") as f:
        f.seek(80)
        n_tri = struct.unpack("<I", f.read(4))[0]
        record_dtype = np.dtype([
            ('normal', '<f4', (3,)),
            ('v1', '<f4', (3,)),
            ('v2', '<f4', (3,)),
            ('v3', '<f4', (3,)),
            ('attr', '<u2')
        ])
        data = np.frombuffer(f.read(n_tri * 50), dtype=record_dtype)
        verts = np.stack([data['v1'], data['v2'], data['v3']], axis=1).reshape(-1, 3)
        return verts.astype(np.float32)

if __name__ == "__main__":
    stl_dir = r"C:\Users\naoufal\.gemini\antigravity\scratch\co-detector-controller\enclosure\stl"
    out_html = r"C:\Users\naoufal\.gemini\antigravity\scratch\co-detector-controller\enclosure\docs\interactive_3d_preview.html"
    os.makedirs(os.path.dirname(out_html), exist_ok=True)
    
    parts = {
        "base": ("co_detector_enclosure_base_shell.stl", [0.22, 0.24, 0.27], "Base Shell"),
        "top": ("co_detector_enclosure_top_cover.stl", [0.92, 0.94, 0.96], "Top Smart Cover"),
        "bracket": ("co_detector_enclosure_wall_bracket.stl", [0.15, 0.16, 0.18], "Wall Bracket"),
        "buttons": ("co_detector_enclosure_button_actuator.stl", [0.12, 0.48, 0.95], "Button Actuator"),
        "lightpipes": ("co_detector_enclosure_light_pipe.stl", [0.85, 0.92, 0.98], "Optical Light Pipes"),
    }
    
    encoded_parts = {}
    for key, (filename, color, label) in parts.items():
        path = os.path.join(stl_dir, filename)
        verts = read_stl_vertices(path)
        verts[:, 0] -= 41.0
        verts[:, 1] -= 31.0
        raw_b64 = base64.b64encode(verts.tobytes()).decode("ascii")
        encoded_parts[key] = {
            "name": label,
            "color": color,
            "count": len(verts),
            "data": raw_b64
        }
        print(f"Serialized {label}: {len(verts)} vertices")
        
    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Smart CO + LPG Detector Enclosure - 3D Interactive Viewer</title>
<style>
  :root {{
    --bg-primary: #0f141c;
    --bg-secondary: #1a2230;
    --accent: #2563eb;
    --accent-hover: #3b82f6;
    --text-primary: #f8fafc;
    --text-muted: #94a3b8;
    --card-border: rgba(255, 255, 255, 0.08);
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    background: var(--bg-primary);
    color: var(--text-primary);
    overflow: hidden;
    height: 100vh;
    display: flex;
  }}
  #canvas-container {{
    flex: 1;
    position: relative;
    height: 100%;
  }}
  #sidebar {{
    width: 380px;
    background: var(--bg-secondary);
    border-left: 1px solid var(--card-border);
    display: flex;
    flex-direction: column;
    padding: 24px;
    gap: 20px;
    overflow-y: auto;
    z-index: 10;
    box-shadow: -4px 0 24px rgba(0,0,0,0.4);
  }}
  h1 {{ font-size: 20px; font-weight: 700; color: #fff; line-height: 1.3; }}
  .badge {{
    display: inline-block;
    padding: 4px 8px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-radius: 4px;
    background: rgba(37, 99, 235, 0.2);
    color: #60a5fa;
    border: 1px solid rgba(37, 99, 235, 0.4);
    margin-bottom: 8px;
  }}
  .section {{
    background: rgba(255, 255, 255, 0.03);
    border: 1px solid var(--card-border);
    border-radius: 8px;
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 12px;
  }}
  .section-title {{
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    color: var(--text-muted);
  }}
  .control-row {{
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 13px;
  }}
  .slider-container {{
    display: flex;
    flex-direction: column;
    gap: 6px;
  }}
  input[type="range"] {{
    -webkit-appearance: none;
    width: 100%;
    height: 6px;
    border-radius: 3px;
    background: rgba(255,255,255,0.15);
    outline: none;
  }}
  input[type="range"]::-webkit-slider-thumb {{
    -webkit-appearance: none;
    appearance: none;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    background: var(--accent);
    cursor: pointer;
    box-shadow: 0 0 10px rgba(37, 99, 235, 0.5);
  }}
  .btn-grid {{
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
  }}
  button.preset-btn {{
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid var(--card-border);
    color: var(--text-primary);
    padding: 8px 4px;
    font-size: 12px;
    font-weight: 500;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s;
  }}
  button.preset-btn:hover {{
    background: var(--accent);
    border-color: var(--accent);
  }}
  .toggle-item {{
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 13px;
    cursor: pointer;
    user-select: none;
  }}
  .color-swatch {{
    width: 14px;
    height: 14px;
    border-radius: 3px;
    border: 1px solid rgba(255,255,255,0.2);
  }}
  .spec-grid {{
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    font-size: 12px;
  }}
  .spec-item {{
    background: rgba(0,0,0,0.2);
    padding: 8px;
    border-radius: 4px;
    border: 1px solid rgba(255,255,255,0.04);
  }}
  .spec-label {{ color: var(--text-muted); font-size: 11px; }}
  .spec-value {{ font-weight: 600; color: #fff; margin-top: 2px; }}
  #hud {{
    position: absolute;
    bottom: 24px;
    left: 24px;
    background: rgba(15, 20, 28, 0.85);
    backdrop-filter: blur(8px);
    border: 1px solid var(--card-border);
    border-radius: 8px;
    padding: 12px 18px;
    font-size: 12px;
    color: var(--text-muted);
    pointer-events: none;
    box-shadow: 0 4px 16px rgba(0,0,0,0.3);
  }}
  #hud span {{ color: #fff; font-weight: 600; }}
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
</head>
<body>

<div id="canvas-container">
  <div id="hud">
    Rotate: <span>Left Click + Drag</span> | Pan: <span>Right Click + Drag</span> | Zoom: <span>Scroll</span>
  </div>
</div>

<div id="sidebar">
  <div>
    <div class="badge">KiCad Rev 2.0 Synchronized</div>
    <h1>Smart CO + LPG Controller Enclosure</h1>
    <p style="font-size: 13px; color: var(--text-muted); margin-top: 4px;">
      100% Mechanically Matched to PCB Layout (70×50mm)
    </p>
  </div>

  <div class="section">
    <div class="section-title">Exploded Assembly View</div>
    <div class="slider-container">
      <div class="control-row">
        <span>Explode Distance</span>
        <span id="explode-val" style="font-weight:600; color:#60a5fa;">0 mm</span>
      </div>
      <input type="range" id="explode-slider" min="0" max="60" value="0" step="1">
    </div>
  </div>

  <div class="section">
    <div class="section-title">View Orientation</div>
    <div class="btn-grid">
      <button class="preset-btn" onclick="setView('iso')">Isometric</button>
      <button class="preset-btn" onclick="setView('front')">Front</button>
      <button class="preset-btn" onclick="setView('top')">Top</button>
      <button class="preset-btn" onclick="setView('side')">Side / Ports</button>
      <button class="preset-btn" onclick="setView('bottom')">Wall Mount</button>
      <button class="preset-btn" onclick="setView('reset')">Reset View</button>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Component Visibility</div>
    <label class="toggle-item">
      <input type="checkbox" id="chk-top" checked onchange="togglePart('top', this.checked)">
      <div class="color-swatch" style="background: #e2e8f0;"></div>
      <span>Top Smart Cover (Polar Silver)</span>
    </label>
    <label class="toggle-item">
      <input type="checkbox" id="chk-buttons" checked onchange="togglePart('buttons', this.checked)">
      <div class="color-swatch" style="background: #2563eb;"></div>
      <span>Dual Action Tactile Buttons (HUSH/TEST)</span>
    </label>
    <label class="toggle-item">
      <input type="checkbox" id="chk-lightpipes" checked onchange="togglePart('lightpipes', this.checked)">
      <div class="color-swatch" style="background: #bae6fd;"></div>
      <span>Quad Optical Light Guide Bar</span>
    </label>
    <label class="toggle-item">
      <input type="checkbox" id="chk-base" checked onchange="togglePart('base', this.checked)">
      <div class="color-swatch" style="background: #334155;"></div>
      <span>Base Shell (Dark Slate)</span>
    </label>
    <label class="toggle-item">
      <input type="checkbox" id="chk-bracket" checked onchange="togglePart('bracket', this.checked)">
      <div class="color-swatch" style="background: #1e293b;"></div>
      <span>Quick-Release Wall Bracket</span>
    </label>
    <label class="toggle-item">
      <input type="checkbox" id="chk-pcb" checked onchange="togglePart('pcb', this.checked)">
      <div class="color-swatch" style="background: #15803d;"></div>
      <span>PCB & Sensor Simulation Mockup</span>
    </label>
    <label class="toggle-item" style="margin-top: 6px;">
      <input type="checkbox" id="chk-wire" onchange="toggleWireframe(this.checked)">
      <span>Wireframe CAD Mode</span>
    </label>
  </div>

  <div class="section">
    <div class="section-title">Synchronized Mechanical Alignment</div>
    <div class="spec-grid">
      <div class="spec-item">
        <div class="spec-label">CO Sensor (S1)</div>
        <div class="spec-value">Bottom-Right (56.5, 35.5)</div>
      </div>
      <div class="spec-item">
        <div class="spec-label">LPG Sensor (S2)</div>
        <div class="spec-value">Top-Right (59.0, 6.5)</div>
      </div>
      <div class="spec-item">
        <div class="spec-label">Piezo Buzzer (LS1)</div>
        <div class="spec-value">Bottom-Left (32.0, 38.0)</div>
      </div>
      <div class="spec-item">
        <div class="spec-label">Dual Buttons</div>
        <div class="spec-value">Bottom-Center (42.0, 41.0)</div>
      </div>
      <div class="spec-item">
        <div class="spec-label">Status LEDs</div>
        <div class="spec-value">Bottom Edge (Y = 46.0)</div>
      </div>
      <div class="spec-item">
        <div class="spec-label">OLED Window</div>
        <div class="spec-value">Top-Center (35.5, 13.0)</div>
      </div>
      <div class="spec-item">
        <div class="spec-label">Power IN (J1)</div>
        <div class="spec-value">Top-Left (4.3, 12.0)</div>
      </div>
      <div class="spec-item">
        <div class="spec-label">Valve OUT (J2)</div>
        <div class="spec-value">Bottom-Left (4.5, 38.0)</div>
      </div>
    </div>
  </div>
</div>

<script>
const rawData = {json.dumps(encoded_parts)};

let scene, camera, renderer, controls;
const meshes = {{}};
let pcbGroup;

function init() {{
  const container = document.getElementById('canvas-container');
  
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0f141c);
  scene.fog = new THREE.Fog(0x0f141c, 150, 400);

  camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 1, 1000);
  camera.position.set(110, 95, 120);

  renderer = new THREE.WebGLRenderer({{ antialias: true }});
  renderer.setSize(container.clientWidth, container.clientHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  container.appendChild(renderer.domElement);

  controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.05;
  controls.target.set(0, 0, 10);

  const ambientLight = new THREE.AmbientLight(0xffffff, 0.65);
  scene.add(ambientLight);

  const dirLight1 = new THREE.DirectionalLight(0xffffff, 0.85);
  dirLight1.position.set(80, 120, 100);
  dirLight1.castShadow = true;
  scene.add(dirLight1);

  const dirLight2 = new THREE.DirectionalLight(0x60a5fa, 0.35);
  dirLight2.position.set(-80, -40, 50);
  scene.add(dirLight2);

  const grid = new THREE.GridHelper(200, 20, 0x334155, 0x1e293b);
  grid.position.z = -15;
  grid.rotation.x = Math.PI / 2;
  scene.add(grid);

  for (const [key, part] of Object.entries(rawData)) {{
    const binaryStr = atob(part.data);
    const len = binaryStr.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = binaryStr.charCodeAt(i);
    const floatArr = new Float32Array(bytes.buffer);
    
    const geom = new THREE.BufferGeometry();
    geom.setAttribute('position', new THREE.BufferAttribute(floatArr, 3));
    geom.computeVertexNormals();

    const mat = new THREE.MeshPhysicalMaterial({{
      color: new THREE.Color(part.color[0], part.color[1], part.color[2]),
      roughness: key === 'lightpipes' ? 0.1 : 0.35,
      metalness: 0.1,
      transmission: key === 'lightpipes' ? 0.75 : 0.0,
      transparent: key === 'lightpipes',
      opacity: key === 'lightpipes' ? 0.85 : 1.0,
      clearcoat: key === 'top' ? 0.3 : 0.0,
      clearcoatRoughness: 0.2
    }});

    const mesh = new THREE.Mesh(geom, mat);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    
    if (key === 'top') mesh.position.z = 8.5;
    if (key === 'buttons') mesh.position.set(42.0 - 35, 41.0 - 25, 25.0);
    if (key === 'lightpipes') mesh.position.set(31.6 - 35, 46.0 - 25, 22.0);
    if (key === 'bracket') mesh.position.z = -5.5;

    meshes[key] = mesh;
    scene.add(mesh);
  }}

  // Build PCB & Sensor Mockup (Exact KiCad PCB Footprints)
  pcbGroup = new THREE.Group();
  
  const pcbGeom = new THREE.BoxGeometry(70, 50, 1.6);
  const pcbMat = new THREE.MeshStandardMaterial({{ color: 0x15803d, roughness: 0.4 }});
  const pcbMesh = new THREE.Mesh(pcbGeom, pcbMat);
  pcbMesh.position.set(0, 0, 0.8);
  pcbGroup.add(pcbMesh);

  // Winsen ME3-CO Sensor: Bottom-Right at (56.50, 35.50)
  const coGeom = new THREE.CylinderGeometry(10, 10, 15.1, 32);
  const coMat = new THREE.MeshStandardMaterial({{ color: 0xe65100, roughness: 0.3 }});
  const coMesh = new THREE.Mesh(coGeom, coMat);
  coMesh.rotation.x = Math.PI / 2;
  coMesh.position.set(56.50 - 35, 35.50 - 25, 1.6 + 15.1 / 2);
  pcbGroup.add(coMesh);

  // Figaro TGS2610 LPG MOS Sensor: Top-Right at (59.00, 6.50)
  const lpgGeom = new THREE.CylinderGeometry(4.6, 4.6, 7.9, 24);
  const lpgMat = new THREE.MeshStandardMaterial({{ color: 0x94a3b8, metalness: 0.8, roughness: 0.2 }});
  const lpgMesh = new THREE.Mesh(lpgGeom, lpgMat);
  lpgMesh.rotation.x = Math.PI / 2;
  lpgMesh.position.set(59.00 - 35, 6.50 - 25, 1.6 + 7.9 / 2);
  pcbGroup.add(lpgMesh);

  // Piezo Buzzer: Bottom-Left at (32.00, 38.00)
  const buzGeom = new THREE.CylinderGeometry(6.1, 6.1, 6.5, 24);
  const buzMat = new THREE.MeshStandardMaterial({{ color: 0x1e293b, roughness: 0.5 }});
  const buzMesh = new THREE.Mesh(buzGeom, buzMat);
  buzMesh.rotation.x = Math.PI / 2;
  buzMesh.position.set(32.00 - 35, 38.00 - 25, 1.6 + 6.5 / 2);
  pcbGroup.add(buzMesh);

  // OLED Screen Module: Top-Center at (35.50, 13.00)
  const oledGeom = new THREE.BoxGeometry(27, 14, 2.0);
  const oledMat = new THREE.MeshStandardMaterial({{ color: 0x020617, roughness: 0.1 }});
  const oledMesh = new THREE.Mesh(oledGeom, oledMat);
  oledMesh.position.set(35.50 - 35, 13.00 - 25, 1.6 + 6.0);
  pcbGroup.add(oledMesh);

  pcbGroup.position.z = 4.0;
  scene.add(pcbGroup);

  window.addEventListener('resize', onWindowResize);
  document.getElementById('explode-slider').addEventListener('input', updateExplosion);

  animate();
}}

function updateExplosion(e) {{
  const d = parseFloat(e.target.value);
  document.getElementById('explode-val').textContent = d + " mm";

  if (meshes.top) meshes.top.position.z = 8.5 + d;
  if (meshes.buttons) meshes.buttons.position.z = 25.0 + d * 1.5;
  if (meshes.lightpipes) meshes.lightpipes.position.z = 22.0 + d * 1.4;
  if (meshes.bracket) meshes.bracket.position.z = -5.5 - d * 0.8;
  if (pcbGroup) pcbGroup.position.z = 4.0 + d * 0.3;
}}

function setView(mode) {{
  let targetPos;
  if (mode === 'iso') targetPos = new THREE.Vector3(110, 95, 120);
  else if (mode === 'front') targetPos = new THREE.Vector3(0, 0, 150);
  else if (mode === 'top') targetPos = new THREE.Vector3(0, 160, 20);
  else if (mode === 'side') targetPos = new THREE.Vector3(-150, 0, 10);
  else if (mode === 'bottom') targetPos = new THREE.Vector3(0, 0, -150);
  else if (mode === 'reset') targetPos = new THREE.Vector3(110, 95, 120);

  if (targetPos) {{
    camera.position.copy(targetPos);
    controls.target.set(0, 0, 10);
    controls.update();
  }}
}}

function togglePart(part, visible) {{
  if (part === 'pcb' && pcbGroup) pcbGroup.visible = visible;
  else if (meshes[part]) meshes[part].visible = visible;
}}

function toggleWireframe(enabled) {{
  for (const m of Object.values(meshes)) {{
    m.material.wireframe = enabled;
  }}
}}

function onWindowResize() {{
  const container = document.getElementById('canvas-container');
  camera.aspect = container.clientWidth / container.clientHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(container.clientWidth, container.clientHeight);
}}

function animate() {{
  requestAnimationFrame(animate);
  controls.update();
  renderer.render(scene, camera);
}}

window.onload = init;
</script>
</body>
</html>
"""

    with open(out_html, "w", encoding="utf-8") as f:
        f.write(html_content)
    print(f"Generated standalone interactive 3D viewer: {out_html} ({os.path.getsize(out_html)/1024:.1f} KB)")
