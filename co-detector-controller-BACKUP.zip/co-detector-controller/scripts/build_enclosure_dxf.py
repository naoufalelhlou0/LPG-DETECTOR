"""
build_enclosure_dxf.py
Generates AutoCAD-compatible 2D DXF files for:
1. Laser-cut Acrylic Front OLED Protection Window Lens
2. Silicone Dust / Ingress Sealing Perimeter Gasket
3. Wall-Mount Drilling & Gang-Box Installation Template
"""

import math
import os

def create_dxf_polyline_with_arcs(entities, layer="CUT", color=7):
    """
    entities: list of line segments or arcs:
      ('LINE', x1, y1, x2, y2)
      ('CIRCLE', cx, cy, r)
      ('ARC', cx, cy, r, start_ang_deg, end_ang_deg)
    """
    out = [
        "0", "SECTION",
        "2", "HEADER",
        "9", "$ACADVER",
        "1", "AC1009",
        "0", "ENDSEC",
        "0", "SECTION",
        "2", "ENTITIES"
    ]
    
    for item in entities:
        kind = item[0]
        if kind == "LINE":
            _, x1, y1, x2, y2 = item
            out.extend([
                "0", "LINE",
                "8", layer,
                "62", str(color),
                "10", f"{x1:.4f}",
                "20", f"{y1:.4f}",
                "30", "0.0",
                "11", f"{x2:.4f}",
                "21", f"{y2:.4f}",
                "31", "0.0"
            ])
        elif kind == "CIRCLE":
            _, cx, cy, r = item
            out.extend([
                "0", "CIRCLE",
                "8", layer,
                "62", str(color),
                "10", f"{cx:.4f}",
                "20", f"{cy:.4f}",
                "30", "0.0",
                "40", f"{r:.4f}"
            ])
        elif kind == "ARC":
            _, cx, cy, r, a1, a2 = item
            out.extend([
                "0", "ARC",
                "8", layer,
                "62", str(color),
                "10", f"{cx:.4f}",
                "20", f"{cy:.4f}",
                "30", "0.0",
                "40", f"{r:.4f}",
                "50", f"{a1:.4f}",
                "51", f"{a2:.4f}"
            ])
            
    out.extend([
        "0", "ENDSEC",
        "0", "EOF"
    ])
    return "\n".join(out)


def rounded_rect_entities(w, h, r, offset_x=0.0, offset_y=0.0):
    ents = []
    # 4 straight segments
    ents.append(('LINE', offset_x + r, offset_y, offset_x + w - r, offset_y))
    ents.append(('LINE', offset_x + w, offset_y + r, offset_x + w, offset_y + h - r))
    ents.append(('LINE', offset_x + w - r, offset_y + h, offset_x + r, offset_y + h))
    ents.append(('LINE', offset_x, offset_y + h - r, offset_x, offset_y + r))
    # 4 corner arcs
    ents.append(('ARC', offset_x + w - r, offset_y + r, r, 270.0, 360.0))
    ents.append(('ARC', offset_x + w - r, offset_y + h - r, r, 0.0, 90.0))
    ents.append(('ARC', offset_x + r, offset_y + h - r, r, 90.0, 180.0))
    ents.append(('ARC', offset_x + r, offset_y + r, r, 180.0, 270.0))
    return ents


if __name__ == "__main__":
    out_dir = r"C:\Users\naoufal\.gemini\antigravity\scratch\co-detector-controller\enclosure\cad"
    os.makedirs(out_dir, exist_ok=True)
    
    # 1. Acrylic Front Lens DXF (27.0mm x 16.0mm with 1.5mm fillet, 1.5mm clear PMMA)
    lens_ents = rounded_rect_entities(27.0, 16.0, 1.5)
    lens_dxf = create_dxf_polyline_with_arcs(lens_ents, layer="LASER_CUT_LENS", color=1)
    lens_file = os.path.join(out_dir, "acrylic_display_lens.dxf")
    with open(lens_file, "w") as f:
        f.write(lens_dxf)
    print(f"Generated {lens_file}")
    
    # 2. Silicone Perimeter Sealing Gasket DXF (Outer: 78.0 x 58.0mm, Inner: 74.4 x 54.4mm, width: 1.8mm)
    gasket_ents = []
    gasket_ents.extend(rounded_rect_entities(78.0, 58.0, 4.0))
    gasket_ents.extend(rounded_rect_entities(74.4, 54.4, 2.2, offset_x=1.8, offset_y=1.8))
    gasket_dxf = create_dxf_polyline_with_arcs(gasket_ents, layer="GASKET_CUT", color=3)
    gasket_file = os.path.join(out_dir, "perimeter_sealing_gasket.dxf")
    with open(gasket_file, "w") as f:
        f.write(gasket_dxf)
    print(f"Generated {gasket_file}")
    
    # 3. Wall Mount Drilling Template DXF (Standard 60mm European gang box + US single gang box)
    drill_ents = []
    drill_ents.extend(rounded_rect_entities(82.0, 62.0, 5.0))
    # 60mm European gang box holes (pitch 60.0mm horizontal)
    drill_ents.append(('CIRCLE', 41.0 - 30.0, 31.0, 2.25))
    drill_ents.append(('CIRCLE', 41.0 + 30.0, 31.0, 2.25))
    # US standard vertical mounting holes (pitch 83.3mm or central 40mm)
    drill_ents.append(('CIRCLE', 41.0, 31.0 - 20.0, 2.25))
    drill_ents.append(('CIRCLE', 41.0, 31.0 + 20.0, 2.25))
    # Central cable entry conduit hole (diameter 25.0mm)
    drill_ents.append(('CIRCLE', 41.0, 31.0, 12.5))
    drill_dxf = create_dxf_polyline_with_arcs(drill_ents, layer="WALL_DRILLING_TEMPLATE", color=4)
    drill_file = os.path.join(out_dir, "mounting_drilling_template.dxf")
    with open(drill_file, "w") as f:
        f.write(drill_dxf)
    print(f"Generated {drill_file}")
    print("=== All 2D CAD DXF Files Generated Successfully! ===")

